self.assetsManifest = {
  "version": "iz7+JiW8",
  "assets": [
    {
      "hash": "sha256-TSgzDIY4qdWvjvfBaUSrnerVt2+FjH4cXGlPrxEz1C0=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-hylTyzoFC8Kp1f0FRqBY1LUV5GLhjEZGZbvrFnkZ1Tw=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-4qCjCkeMkrC39fhhzGK6jZVM+CSQXhBgirZfr1DM/6I=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.yv2qi7o6jg.wasm"
    },
    {
      "hash": "sha256-+5+/1obWKmNeB9zuGBeA2beO5qKtdJKqtqHxaoMFDzE=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.fj8j66h5p2.wasm"
    },
    {
      "hash": "sha256-1bZXAq7xg/K+UZT3zZxmJHp4UKNJQBP+2ny+/lGkyHo=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.rwpg67y8a3.wasm"
    },
    {
      "hash": "sha256-2zoMs7dmSopN36l1wcOOXI/h/kpMP7020Ja0nFJ+pDM=",
      "url": "_framework/Microsoft.AspNetCore.Components.vng26hhzhi.wasm"
    },
    {
      "hash": "sha256-3ADlF4CLU1Q+dQbj0MnPVnEJPiA4q4Jv5xxmiGEvBks=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.85u9862gz3.wasm"
    },
    {
      "hash": "sha256-kKMubKJ3c2lATxpoAuoDqMjzQ+a0M6Ym35pK74cMK2o=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.0cm6d8ej68.wasm"
    },
    {
      "hash": "sha256-fN4AyqImDQ+h3H7tFeF4ZSkjIHJ7qWgbKL217x6P53s=",
      "url": "_framework/Microsoft.Extensions.Configuration.cyz6aj3end.wasm"
    },
    {
      "hash": "sha256-5VXbycqxB2z8e0eNzbJF1hWQpERThjnuMktygWHwqNU=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.rk73pqclxf.wasm"
    },
    {
      "hash": "sha256-Sgs1bgmGaF2mv6rWcaihc+x48ZQQAidfzYwZvYX5WJk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.uum8fsrbn4.wasm"
    },
    {
      "hash": "sha256-4+PHiXRpBfIxgpAlp6nMsKunPfQSsDtueIwEMl2o9B4=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.nzqh10agbz.wasm"
    },
    {
      "hash": "sha256-gNy3fBH1UFELrhJ7GxqLy+6tAxI1ca/R0lmCUqiJAkc=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.oq0bc6qwtw.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-uoBWN1EXPb2NuqCrRtfEd0Y1a2QMXfyhRaIKp+eQ/So=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.25xesdv4z6.wasm"
    },
    {
      "hash": "sha256-I/euMiwOKn2U2Y1vqcUjYWEG/7zWmvDiTlHAoPLRHQ0=",
      "url": "_framework/Microsoft.Extensions.Logging.p9svcbtg1a.wasm"
    },
    {
      "hash": "sha256-iCJ7MgEDmi8gJJ4kr+vCM0UW+W51Th0XAwRG1vPU9Ak=",
      "url": "_framework/Microsoft.Extensions.Options.sv9qmqvsmm.wasm"
    },
    {
      "hash": "sha256-WXYpl64HUqc9+prJOz6dOEVvB8PFJhTdfqUMB3ZGRGA=",
      "url": "_framework/Microsoft.Extensions.Primitives.5pxr7nzxwe.wasm"
    },
    {
      "hash": "sha256-TQCxLzfm/SxMgyY5O1pXC+ybxqviCLz3zMZxz+QE9IY=",
      "url": "_framework/Microsoft.JSInterop.5ulb5e6h7c.wasm"
    },
    {
      "hash": "sha256-mpyjzA6YBuV9Qx5BUC8YbXP9YjZlM+k7YTVawzXJFgk=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.imfqvv3x5h.wasm"
    },
    {
      "hash": "sha256-Pjf3czWeMVwiuVjoXL/ByH8J1O11RsUE1oSvT3l7wjQ=",
      "url": "_framework/MudBlazor.mu7ib1zu79.wasm"
    },
    {
      "hash": "sha256-PUP2qsOZY7EIYC2Fax5TOz26m0h6tDVzHJ7VNmiE6B8=",
      "url": "_framework/Services.Base64.lmljz36c67.wasm"
    },
    {
      "hash": "sha256-76zLB1vnKMhkHO62y9yoUtpb6mwWTZrDlPKUBI5BUNE=",
      "url": "_framework/Services.Hashing.zfz25uf5tt.wasm"
    },
    {
      "hash": "sha256-rsP6HyxFyWxaZoORLpPQhxATr3QnmobbWMC6C72HEXY=",
      "url": "_framework/Services.Url.mydgher393.wasm"
    },
    {
      "hash": "sha256-FKQffPnWjROq/We0sU/izP9RpkOaMHro4COdz/E5Gec=",
      "url": "_framework/System.Collections.Concurrent.odg87464p4.wasm"
    },
    {
      "hash": "sha256-Tt9gFH0IeBKovxPeqnJ2rH3UGa5Du+IDj5hhZjxL/R8=",
      "url": "_framework/System.Collections.Immutable.6387w7a7pa.wasm"
    },
    {
      "hash": "sha256-YdI0bTzTRnVGLRFdfVinGcTUNl1a7Lt9qGDrKo1WCX8=",
      "url": "_framework/System.Collections.xwodjogzpm.wasm"
    },
    {
      "hash": "sha256-/TUgJRG3EZB5Bcfo9BEFJ61DIJLAJRTXeLYB1vnMd1Q=",
      "url": "_framework/System.ComponentModel.5y3o4qq5pj.wasm"
    },
    {
      "hash": "sha256-OEUiONvTvRl0zXaRpOxe8N1bZm9G8n1a8O1MU0CuiIs=",
      "url": "_framework/System.ComponentModel.Annotations.c3oteuai4j.wasm"
    },
    {
      "hash": "sha256-kBzp10NYPlN9m9Lu20Aqmqij6KZcgw2iYgcyjE1Oj5M=",
      "url": "_framework/System.ComponentModel.Primitives.gw0gkk5sib.wasm"
    },
    {
      "hash": "sha256-fe53dkPGbPTDsVexItWDMsFKY7AVXufPswNaBhAPX2w=",
      "url": "_framework/System.ComponentModel.TypeConverter.zgmbvnl9ci.wasm"
    },
    {
      "hash": "sha256-Ym2fYLZWqt1BbLEtsJORRBN1tzso2uW90TjIEu+IObA=",
      "url": "_framework/System.Console.ay9cgsff71.wasm"
    },
    {
      "hash": "sha256-FvMFst65VsYJYLk147PRwDkwScBqu6GaqfgdgZJPEhU=",
      "url": "_framework/System.Diagnostics.Debug.2hjyodvs6h.wasm"
    },
    {
      "hash": "sha256-A5jfey0LJ+Y2Ibf0e+YmiL8tJXwT4yZMBo9RZJRJvIU=",
      "url": "_framework/System.IO.Hashing.j85u6rlrk0.wasm"
    },
    {
      "hash": "sha256-ltKNH6AL0soduarPfzy6T90WE3rPgr3GhVxWtFvIglk=",
      "url": "_framework/System.IO.Pipelines.mslxeuynkl.wasm"
    },
    {
      "hash": "sha256-oqN2+xO0FjmwcgzoLho+pZ8p7QdanWXa9fZJiV5IYBg=",
      "url": "_framework/System.Linq.Expressions.qx6x32dve1.wasm"
    },
    {
      "hash": "sha256-e3fCYTXYjQtmxDRT28LWGxAXSzeNwMguGWnokgYlpmg=",
      "url": "_framework/System.Linq.frurbibmmg.wasm"
    },
    {
      "hash": "sha256-cogZ93o17jQq3v9gfbCiEi3NkOEbeJgaWUnNTLgMIfA=",
      "url": "_framework/System.Memory.6vh06ia9tj.wasm"
    },
    {
      "hash": "sha256-AUh9H4KMFMgWv0ROj41gfS07588GWmmrsXuyfoooljc=",
      "url": "_framework/System.Net.Http.xgu7qeey5v.wasm"
    },
    {
      "hash": "sha256-ATD97tYcgeYU6qhLjcFpeIbpkzSMNEqYgBaQAzNMgCQ=",
      "url": "_framework/System.Net.Primitives.xosvhvwc8p.wasm"
    },
    {
      "hash": "sha256-74PWiuVd6tMrwFBvoSFw+DELiEfYweOla/ApAggaCjI=",
      "url": "_framework/System.ObjectModel.zbwxa6saya.wasm"
    },
    {
      "hash": "sha256-GEAmLaPbmcpdl1AydRnrSbJ0ttbOmoKuaA/73POalAY=",
      "url": "_framework/System.Private.CoreLib.waldjo0ho7.wasm"
    },
    {
      "hash": "sha256-bq29+PtqFVdf3lTxJJScrgGz+J7qQ96TLl5M+UorNzk=",
      "url": "_framework/System.Private.Uri.e8835ztk9b.wasm"
    },
    {
      "hash": "sha256-eyoe5u0hWBUxCuDEop8Tq/REDXsu9PqnI8DnccMdJxo=",
      "url": "_framework/System.Resources.ResourceManager.vbl2ycgtbr.wasm"
    },
    {
      "hash": "sha256-g0bEEgDPKhBznjXI9Il3quEH/4vSOnwz4WHq/bg0LPo=",
      "url": "_framework/System.Runtime.3cxvs0r52g.wasm"
    },
    {
      "hash": "sha256-5Gru8lhVTGY7XS1KKVRZjDFARt3p1nsfa1Tj2CPdRsI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.cqbusmqy15.wasm"
    },
    {
      "hash": "sha256-ldFkm/k7yD5rJM19rT6X1jXmW0A03FLLoO9zQ1hW2Uc=",
      "url": "_framework/System.Security.Cryptography.93ysa3g4i1.wasm"
    },
    {
      "hash": "sha256-nowVPzdhrYNVwBj7BFC6KceUhojJ5Gz2vZGxT0qFoSA=",
      "url": "_framework/System.Text.Encodings.Web.e8bnsydrha.wasm"
    },
    {
      "hash": "sha256-WzRV3St+8vMDWCagry39BWKq6oS07q2yFIErgsGBt5w=",
      "url": "_framework/System.Text.Json.b8buwww0l0.wasm"
    },
    {
      "hash": "sha256-jucDaG3uER5OszHfUFkriy4wTbZUSP/Q29um3UE8EwU=",
      "url": "_framework/System.Text.RegularExpressions.yf50ka5y51.wasm"
    },
    {
      "hash": "sha256-qp70A+Fuaia0u/oeAqOzUj6+KwQqMRs3ZMXZNzyP02w=",
      "url": "_framework/System.Threading.Tasks.6k4x85x2wh.wasm"
    },
    {
      "hash": "sha256-hkGLo/MuT/FJ0Xf4XUL0D2VA4dZV532GHNB1JicxLko=",
      "url": "_framework/System.m0fu6d0eya.wasm"
    },
    {
      "hash": "sha256-Nr1Om+nnjT6OfJvTgh/jVrDlloGCicHcEL8OwQaaop0=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-gD2XMSIt+vtDFirTg+LVASuuDVoOW3S7fY2a27Ou3Vs=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-F/5e/lyR+oUxW0davFx8aANjOB+Ddu6RYx2NRUxshPw=",
      "url": "_framework/dotnet.native.vmus01doem.js"
    },
    {
      "hash": "sha256-xSp62gtGzJCHarcKw4O+sE/kU23vmD5SXum3L0V+gqY=",
      "url": "_framework/dotnet.native.vzru81c66e.wasm"
    },
    {
      "hash": "sha256-oBRKHAqZUsvCRnCzkQfB7zc45cpKLNq2NKyrG10IKx8=",
      "url": "_framework/dotnet.runtime.st3wwc8rqy.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-2o28iETl9+u2WW8gZhYRo8LU9P5ZPcuAcwj1tM9tTo8=",
      "url": "_framework/theonlytool.ajfukxxgp8.wasm"
    },
    {
      "hash": "sha256-NdR6BBtG0A492/UR/PUoJ0g3Y19lJ4fdogIrJWMC6TE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-Bvl0FK894vwFfh35ZuoKqStGPaOG41dTwCftaQ9nqFY=",
      "url": "css/pages/home.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-jo0yB1b+8KaynF4Oj+Iesx3Tf75087Zyj23RJXPf7s4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-svmW87cRWYDFEUIqu1/xBr/Rm4WBkScCfekStnqsX0E=",
      "url": "manifest.webmanifest"
    }
  ]
};
