self.assetsManifest = {
  "version": "6CDDRPvu",
  "assets": [
    {
      "hash": "sha256-3FM/mjas9rQiq2CY+FQPy1Pe1iCLSx/qZltQxK4dcuQ=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-Qf9/gSPxTxchB08Wi5WXxjPqw2IQvnyVUW27s7cwoUo=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-4qCjCkeMkrC39fhhzGK6jZVM+CSQXhBgirZfr1DM/6I=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.yv2qi7o6jg.wasm"
    },
    {
      "hash": "sha256-+5+/1obWKmNeB9zuGBeA2beO5qKtdJKqtqHxaoMFDzE=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.fj8j66h5p2.wasm"
    },
    {
      "hash": "sha256-1bZXAq7xg/K+UZT3zZxmJHp4UKNJQBP+2ny+/lGkyHo=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.rwpg67y8a3.wasm"
    },
    {
      "hash": "sha256-2zoMs7dmSopN36l1wcOOXI/h/kpMP7020Ja0nFJ+pDM=",
      "url": "_framework/Microsoft.AspNetCore.Components.vng26hhzhi.wasm"
    },
    {
      "hash": "sha256-3ADlF4CLU1Q+dQbj0MnPVnEJPiA4q4Jv5xxmiGEvBks=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.85u9862gz3.wasm"
    },
    {
      "hash": "sha256-kKMubKJ3c2lATxpoAuoDqMjzQ+a0M6Ym35pK74cMK2o=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.0cm6d8ej68.wasm"
    },
    {
      "hash": "sha256-fN4AyqImDQ+h3H7tFeF4ZSkjIHJ7qWgbKL217x6P53s=",
      "url": "_framework/Microsoft.Extensions.Configuration.cyz6aj3end.wasm"
    },
    {
      "hash": "sha256-dxXtIbV5+SsgGXRNGq6r/wDdE1JwNabSShZGXs16rTY=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.7socdk9i65.wasm"
    },
    {
      "hash": "sha256-Sgs1bgmGaF2mv6rWcaihc+x48ZQQAidfzYwZvYX5WJk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.uum8fsrbn4.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-63CoZs2v8kUdc0XLRhWY4gt+HvG+sALt8MhboCYTjp0=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.bkdtnkwhhv.wasm"
    },
    {
      "hash": "sha256-I/euMiwOKn2U2Y1vqcUjYWEG/7zWmvDiTlHAoPLRHQ0=",
      "url": "_framework/Microsoft.Extensions.Logging.p9svcbtg1a.wasm"
    },
    {
      "hash": "sha256-iCJ7MgEDmi8gJJ4kr+vCM0UW+W51Th0XAwRG1vPU9Ak=",
      "url": "_framework/Microsoft.Extensions.Options.sv9qmqvsmm.wasm"
    },
    {
      "hash": "sha256-WXYpl64HUqc9+prJOz6dOEVvB8PFJhTdfqUMB3ZGRGA=",
      "url": "_framework/Microsoft.Extensions.Primitives.5pxr7nzxwe.wasm"
    },
    {
      "hash": "sha256-TQCxLzfm/SxMgyY5O1pXC+ybxqviCLz3zMZxz+QE9IY=",
      "url": "_framework/Microsoft.JSInterop.5ulb5e6h7c.wasm"
    },
    {
      "hash": "sha256-mpyjzA6YBuV9Qx5BUC8YbXP9YjZlM+k7YTVawzXJFgk=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.imfqvv3x5h.wasm"
    },
    {
      "hash": "sha256-DUKXMPqr4O568JAehLruoBGA35A3rrrHl6KPKsaBLeQ=",
      "url": "_framework/MudBlazor.t0n6cvi02h.wasm"
    },
    {
      "hash": "sha256-crbTUDAwjV33awtJpY1O3pB3dmDUep9pkFcZQ0Piap8=",
      "url": "_framework/System.Collections.Concurrent.yjwfvapqpq.wasm"
    },
    {
      "hash": "sha256-Tt9gFH0IeBKovxPeqnJ2rH3UGa5Du+IDj5hhZjxL/R8=",
      "url": "_framework/System.Collections.Immutable.6387w7a7pa.wasm"
    },
    {
      "hash": "sha256-YdI0bTzTRnVGLRFdfVinGcTUNl1a7Lt9qGDrKo1WCX8=",
      "url": "_framework/System.Collections.xwodjogzpm.wasm"
    },
    {
      "hash": "sha256-/TUgJRG3EZB5Bcfo9BEFJ61DIJLAJRTXeLYB1vnMd1Q=",
      "url": "_framework/System.ComponentModel.5y3o4qq5pj.wasm"
    },
    {
      "hash": "sha256-OEUiONvTvRl0zXaRpOxe8N1bZm9G8n1a8O1MU0CuiIs=",
      "url": "_framework/System.ComponentModel.Annotations.c3oteuai4j.wasm"
    },
    {
      "hash": "sha256-jDB4ONn+ytOxP9ATQtYg8+Z+2V3rMH1Ci9k8CPo9Y8k=",
      "url": "_framework/System.ComponentModel.Primitives.g5fj0nkchn.wasm"
    },
    {
      "hash": "sha256-OLm71vFejrfS7tuHwbQIrbPJJFFvqFC1eM7SgYnxTfA=",
      "url": "_framework/System.Console.gi7zmwq5sa.wasm"
    },
    {
      "hash": "sha256-ltKNH6AL0soduarPfzy6T90WE3rPgr3GhVxWtFvIglk=",
      "url": "_framework/System.IO.Pipelines.mslxeuynkl.wasm"
    },
    {
      "hash": "sha256-oqN2+xO0FjmwcgzoLho+pZ8p7QdanWXa9fZJiV5IYBg=",
      "url": "_framework/System.Linq.Expressions.qx6x32dve1.wasm"
    },
    {
      "hash": "sha256-GCy3YsSIankBSma3f2Xyh/KKutcbaqigu2RQK1ZEmpM=",
      "url": "_framework/System.Linq.o82nddcyqb.wasm"
    },
    {
      "hash": "sha256-cogZ93o17jQq3v9gfbCiEi3NkOEbeJgaWUnNTLgMIfA=",
      "url": "_framework/System.Memory.6vh06ia9tj.wasm"
    },
    {
      "hash": "sha256-AUh9H4KMFMgWv0ROj41gfS07588GWmmrsXuyfoooljc=",
      "url": "_framework/System.Net.Http.xgu7qeey5v.wasm"
    },
    {
      "hash": "sha256-ATD97tYcgeYU6qhLjcFpeIbpkzSMNEqYgBaQAzNMgCQ=",
      "url": "_framework/System.Net.Primitives.xosvhvwc8p.wasm"
    },
    {
      "hash": "sha256-h6XzU8dmPnnMKyM+Kh7pOJcnBxSBojy/aIQYuzJEu2k=",
      "url": "_framework/System.Private.CoreLib.dvd1almx2q.wasm"
    },
    {
      "hash": "sha256-bq29+PtqFVdf3lTxJJScrgGz+J7qQ96TLl5M+UorNzk=",
      "url": "_framework/System.Private.Uri.e8835ztk9b.wasm"
    },
    {
      "hash": "sha256-5Gru8lhVTGY7XS1KKVRZjDFARt3p1nsfa1Tj2CPdRsI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.cqbusmqy15.wasm"
    },
    {
      "hash": "sha256-gPApnWAv2h7aJU14ijnyB5bgb+rV1WAeQPmzz5okEtY=",
      "url": "_framework/System.Runtime.wos14tr85r.wasm"
    },
    {
      "hash": "sha256-nowVPzdhrYNVwBj7BFC6KceUhojJ5Gz2vZGxT0qFoSA=",
      "url": "_framework/System.Text.Encodings.Web.e8bnsydrha.wasm"
    },
    {
      "hash": "sha256-WzRV3St+8vMDWCagry39BWKq6oS07q2yFIErgsGBt5w=",
      "url": "_framework/System.Text.Json.b8buwww0l0.wasm"
    },
    {
      "hash": "sha256-FC3WylgN6TsexKj0k5f6UXGT1/MJ9bSvKXKHPPGcmQQ=",
      "url": "_framework/System.Text.RegularExpressions.g9kimkxdqf.wasm"
    },
    {
      "hash": "sha256-ErAC8TFweFH6fRFAfAqOeb3be2IhU238TXyd/YLuBrE=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-gD2XMSIt+vtDFirTg+LVASuuDVoOW3S7fY2a27Ou3Vs=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-FXEl+bfyPKTpa9m/Ykoe1mk+3r5e81mf/atd+l7cS3Y=",
      "url": "_framework/dotnet.native.7lj3trktf2.wasm"
    },
    {
      "hash": "sha256-F/5e/lyR+oUxW0davFx8aANjOB+Ddu6RYx2NRUxshPw=",
      "url": "_framework/dotnet.native.vmus01doem.js"
    },
    {
      "hash": "sha256-oBRKHAqZUsvCRnCzkQfB7zc45cpKLNq2NKyrG10IKx8=",
      "url": "_framework/dotnet.runtime.st3wwc8rqy.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-4mske4Ztbk70rHPsRKX1756521xGN2M0NfK6OXfdj2A=",
      "url": "_framework/theonlytool.y7spp8q7ow.wasm"
    },
    {
      "hash": "sha256-NdR6BBtG0A492/UR/PUoJ0g3Y19lJ4fdogIrJWMC6TE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-oMRz4rSGMpOu9pr0+L+EYyGlyEHBk9TEskT5PrPFMIU=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-ItsH+WxHbCRBanvk7daRF+6VkIlldGi4UwLlFyBfO0Y=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-4EFQQGBU1DxEpPpbqTAbOSNuGAbKv/QjJp7jpRx+aKc=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-ImGEwjeKQ7KyOBWGPlYJ9DyX5SUbq08eOc7ESquwd1w=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-GwbdwIrBY6HRkFmsG2pAnGxumVs8C1uHFl+tadHBk3s=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-PDSg5q1nglwQlHjD2m/3n8+3Nr8dB+echJQ1kEFpwZk=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-eklwH4dKff9tCqdcL2VGRFNfl/aCLpYLecovNmCRx4I=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-y2+RHIhTFusaZbE86rcKnRNBqZ3qcwWjze7Ovc4cX1E=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-2hvmG9yF/52H5pM2P9PDtQ/MXoThkp3XBpjXwXP8Nr4=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-jJHQjHos9iDuTGOQGHB1rc7Vb/5J8T70FFAh9bb/xyQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-svmW87cRWYDFEUIqu1/xBr/Rm4WBkScCfekStnqsX0E=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-paIeuWnSzjeLGITWkk4p3rcejUsZWCJGPeOK9UhWXtg=",
      "url": "sample-data/weather.json"
    }
  ]
};
